# cropperjs-ejemplo
<p>Ejemplo de como usar cropper js, tutorial realizado por <a href="https://www.youtube.com/user/jj43ist?sub_confirmation=1" target="_blank">JotaTuts</a><br> Link del turorial: <a href="https://youtu.be/xS2VrknVfzE" target="_blank">https://youtu.be/xS2VrknVfzE</a></p>
<p>Capturas de pantalla:</p>
<p>
  <img src="https://www.mediafire.com/convkey/fb89/ly0dzbrpsf454dc9g.jpg" alt="interfaz">
</p>
<p>
  <img src="https://www.mediafire.com/convkey/ce35/ykpm4qpt9m6jp7i9g.jpg" alt="cropper">
</p>
<p>
  <img src="https://www.mediafire.com/convkey/3a94/rk7svqwumfefk5j9g.jpg" alt="imagen cortada"
</p>
